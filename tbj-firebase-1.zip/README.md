# TBJ News Firebase Version

Website berita dengan Firebase Firestore + Storage.
